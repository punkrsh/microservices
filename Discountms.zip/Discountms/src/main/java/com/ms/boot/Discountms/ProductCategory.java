package com.ms.boot.Discountms;

public enum ProductCategory {
	FURNISHING,
	KITCHENELECTRONIC,
	TOY,
	MOBILEPHONE,
	MEDICALEQUIPMENT,
	MUSICINSTRUMENT
	

}

package com.ms.boot.Discountms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountmsApplicationTests {

	@Test
	void contextLoads() {
	}

}

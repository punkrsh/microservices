package com.ms.boot.Productms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductmsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.ms.boot.Productms.model;

public enum ProductCategory {
	FURNISHING,
	KITCHENELECTRONIC,
	TOY,
	MOBILEPHONE,
	MEDICALEQUIPMENT,
	MUSICINSTRUMENT
	

}
